"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'wind';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'wind';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJQTFVHSU5fTkFNRSJdLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBQTFVHSU5fSUQgPSAnd2luZCc7XG5leHBvcnQgY29uc3QgUExVR0lOX05BTUUgPSAnd2luZCc7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFPLE1BQU1BLFNBQVMsR0FBRyxNQUFNO0FBQUM7QUFDekIsTUFBTUMsV0FBVyxHQUFHLE1BQU07QUFBQyJ9